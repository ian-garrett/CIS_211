words = ['hawk', 'hen', 'hog', 'hyena']

double_iter = [[(l,word) for l in word]for word in words]
